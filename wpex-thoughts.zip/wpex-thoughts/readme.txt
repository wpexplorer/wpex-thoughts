========================================
= Theme created by AJ Clarke from WPExplorer.com
= GNU General Public License version 3.0

========================================
== Resources Used (thanks!)
========================================
* jQuery - http://jquery.com/
* Superfish - http://users.tpg.com.au/j_birch/plugins/superfish/
* HoverIntent - http://cherne.net/brian/resources/jquery.hoverIntent.html
* PrettyPhoto - http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/
* FlexSlider - http://www.woothemes.com/flexslider/
* Fitvids - http://fitvidsjs.com/
* Font Awesome - http://fortawesome.github.com/Font-Awesome/
* Uniform - http://uniformjs.com/
* Fatcow Icons - http://www.fatcow.com/free-icons 
* Post Type Icons - http://p.yusukekamiyamane.com/
* Easing - http://gsgd.co.uk/sandbox/jquery/easing/


========================================
== Support?
========================================
* If you wish to support me please consider purchasing one of my commercial themes
at the following address: themeforest.net/user/WPExplorer/portfolio?ref=wpexplorer

Thanks!